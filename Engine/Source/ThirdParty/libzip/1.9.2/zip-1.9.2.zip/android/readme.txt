
Cross compile libzip for android.
--------------------------------
Modify "do.sh" as appropriate if you need to specify a different ndk dir or wish to specify different build parameters

Prerequisites for the development machine - see docker/Dockerfile

You can either set you host machine up with these prerequisites or simply use docker (in which case you need not install anything on your host machine except docker itself).

See "Usage" in docker/Dockerfile for detailed instructions.
