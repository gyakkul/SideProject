run_build.bat shows how to run a Steam content build for AppID 1000 which has one depot 1001.
