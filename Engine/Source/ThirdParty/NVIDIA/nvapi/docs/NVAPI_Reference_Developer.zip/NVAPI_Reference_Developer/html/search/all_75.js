var searchData=
[
  ['u32currentvalue',['u32CurrentValue',['../group__vidio.html#ga64a730602dded7409fd25be661f5e619',1,'_NVDRS_SETTING_V1']]],
  ['u32defaultvalue',['u32DefaultValue',['../group__vidio.html#ga9145138952a708b3f8d6207310a589e7',1,'_NVDRS_SETTING_VALUES']]],
  ['u32predefinedvalue',['u32PredefinedValue',['../group__vidio.html#ga549a2a24058eb9ef76f90a99d07ebe30',1,'_NVDRS_SETTING_V1']]],
  ['u32value',['u32Value',['../group__vidio.html#ga644707e439359e17bfbc19e8a855b5d9',1,'_NVDRS_SETTING_VALUES']]],
  ['ublue',['uBlue',['../group__vidio.html#ga8a85527cc91d1df07418f8a9bf22c12d',1,'_NVVIOGAMMARAMP8::uBlue()'],['../group__vidio.html#ga2bb3efbdaf3b8703ea029e7dbb454120',1,'_NVVIOGAMMARAMP10::uBlue()']]],
  ['ugreen',['uGreen',['../group__vidio.html#gae5d4fb477badabd4df8942eb7c97986c',1,'_NVVIOGAMMARAMP8::uGreen()'],['../group__vidio.html#ga8ebfa86f93a3e8955068ef86b6f68fd5',1,'_NVVIOGAMMARAMP10::uGreen()']]],
  ['upoweron',['uPowerOn',['../group__vidio.html#gaabb94426b288a68b493792cb841d0525',1,'_NVVIOOUTPUTSTATUS']]],
  ['ured',['uRed',['../group__vidio.html#gabe2a2ead2f6bc2fce402dc78157154ed',1,'_NVVIOGAMMARAMP8::uRed()'],['../group__vidio.html#ga57c691dbd35501b1d0e70b4ee690e6ac',1,'_NVVIOGAMMARAMP10::uRed()']]],
  ['userfriendlyname',['userFriendlyName',['../group__vidio.html#ga33e0a8547bd9d409703e7f5065bb6a9a',1,'_NVDRS_APPLICATION_V1::userFriendlyName()'],['../group__vidio.html#ga3cfdea8f4eaad0f96b088e2c1101da09',1,'_NVDRS_APPLICATION_V2::userFriendlyName()'],['../group__vidio.html#ga793b8e11a654c841dbb56f82f5514bc8',1,'_NVDRS_APPLICATION_V3::userFriendlyName()'],['../group__vidio.html#ga0b05a3c4682445fbb0a6db55ff1866b0',1,'_NVDRS_APPLICATION_V4::userFriendlyName()']]],
  ['usyncsourcelocked',['uSyncSourceLocked',['../group__vidio.html#ga062fd0a44ce9d5deef880c63ae4f5b7d',1,'_NVVIOOUTPUTSTATUS']]],
  ['utilid',['utilId',['../group__vidio.html#gabbb708323b6df9734501b6784dc615de',1,'_NV_GPU_CLIENT_UTILIZATION_DATA_V1']]],
  ['utilizationpercent',['utilizationPercent',['../group__vidio.html#gaf3fb95eb5f7668b730b25ca281acf474',1,'_NV_GPU_CLIENT_UTILIZATION_DATA_V1']]],
  ['utils',['utils',['../group__vidio.html#gac3f6831c9eea86fa269ff1f86b0f922f',1,'_NV_GPU_CLIENT_CALLBACK_UTILIZATION_DATA_V1']]]
];
