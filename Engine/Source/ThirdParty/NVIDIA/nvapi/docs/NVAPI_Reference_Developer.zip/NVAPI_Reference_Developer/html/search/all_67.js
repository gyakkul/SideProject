var searchData=
[
  ['gammaramp',['gammaRamp',['../group__vidio.html#gad936a1496df1777cb7a4a14d8d8579df',1,'_NVVIOGAMMACORRECTION']]],
  ['gammaramp10',['gammaRamp10',['../group__vidio.html#ga0f4aaff76fea7e7e703f9ffe6a9e7541',1,'_NVVIOGAMMACORRECTION']]],
  ['gammaramp8',['gammaRamp8',['../group__vidio.html#gaa73c0bf6bb2339cd4505c43ba60fbc9b',1,'_NVVIOGAMMACORRECTION']]],
  ['gpiopinblue',['gpioPinBlue',['../group__vidio.html#gafa98c150150e26adfafc35a3c8e8b764',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopingreen',['gpioPinGreen',['../group__vidio.html#gac64bfc63eb032b8beea5e364e1b9c94b',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopinred',['gpioPinRed',['../group__vidio.html#ga015308f09fbca43441e916b89414d6cc',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpiopinsinglecolor',['gpioPinSingleColor',['../group__vidio.html#ga1ad056ac67ea56729381ce1466702912',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_SINGLE_COLOR']]],
  ['gpiopinwhite',['gpioPinWhite',['../group__vidio.html#ga4302213f628d60d98632d3439bb4f5b1',1,'_NV_GPU_CLIENT_ILLUM_DEVICE_INFO_DATA_GPIO_PWM_RGBW']]],
  ['gpuactiverendertimeus',['gpuActiveRenderTimeUs',['../group__vidio.html#gab2d1dbacc46dc86426937279395745c1',1,'_NV_LATENCY_RESULT_PARAMS::FrameReport']]],
  ['gpucount',['gpuCount',['../group__vidio.html#gaac83e9820530bfa4d011e38faa7c6179',1,'NV_COMPUTE_GPU_TOPOLOGY_V1::gpuCount()'],['../group__vidio.html#gaf4b85d3323c00fdc09a40ce821a8a6fc',1,'_NV_COMPUTE_GPU_TOPOLOGY_V2::gpuCount()']]],
  ['gpuframetimeus',['gpuFrameTimeUs',['../group__vidio.html#ga2be61eaa2b757435d1b08f46ed9d74ec',1,'_NV_LATENCY_RESULT_PARAMS::FrameReport']]],
  ['gpuid',['gpuId',['../group__vidio.html#gad2ffba6a0981d5aa53bf1dae122c8e52',1,'NV_DISPLAY_PATH']]],
  ['gpusupport',['gpuSupport',['../group__vidio.html#ga2bc6d436c953b83424909036021cce73',1,'_NVDRS_PROFILE_V1']]],
  ['grpcount',['grpCount',['../group__vidio.html#ga10fb675745fa23007afcfc9b873edc38',1,'_NV_GPU_CLIENT_ILLUM_ZONE_CONTROL_DATA_PIECEWISE_LINEAR']]],
  ['grpidletimems',['grpIdleTimems',['../group__vidio.html#gaf1c7d3f8bcef36daf307274732fec0c3',1,'_NV_GPU_CLIENT_ILLUM_ZONE_CONTROL_DATA_PIECEWISE_LINEAR']]]
];
