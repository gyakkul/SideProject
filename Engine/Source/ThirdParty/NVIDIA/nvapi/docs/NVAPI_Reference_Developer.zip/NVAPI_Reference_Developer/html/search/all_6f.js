var searchData=
[
  ['offset',['offset',['../group__vidio.html#ga4c64ff0b019e38cf0630cbb25af9cb87',1,'NV_EDID_V3']]],
  ['offsettexchannels',['offsetTexChannels',['../group__vidio.html#gab13b5a5f2e047dec0b760347411e5c27',1,'NV_SCANOUT_INTENSITY_DATA_V2']]],
  ['offsettexture',['offsetTexture',['../group__vidio.html#gaa6c1611789b136d1d969bac3e785db56',1,'NV_SCANOUT_INTENSITY_DATA_V2']]],
  ['outconfig',['outConfig',['../group__vidio.html#ga4546b1baed61c772031b5a038f488312',1,'_NVVIOCONFIG_V1::outConfig()'],['../group__vidio.html#gaaa5c6e2d6a149d9b92f7d752891ee6d1',1,'_NVVIOCONFIG_V2::outConfig()'],['../group__vidio.html#gae33b19607a7da7033e3268bf5565bca9',1,'_NVVIOCONFIG_V3::outConfig()']]],
  ['outputarea',['outputArea',['../group__vidio.html#gab9707baf7e3912a721af2d34d9c61a2e',1,'_NVVIOOUTPUTCONFIG_V1::outputArea()'],['../group__vidio.html#ga1748ef0e1ce906e81d436e9fa6df79b6',1,'_NVVIOOUTPUTCONFIG_V2::outputArea()'],['../group__vidio.html#ga5669b7ddf796f53fb296abeae3746bce',1,'_NVVIOOUTPUTCONFIG_V3::outputArea()']]],
  ['outputid',['outputId',['../group__vidio.html#ga502172b079178972a517cee92bd2db2d',1,'NVVIOTOPOLOGYTARGET']]],
  ['outputregion',['outputRegion',['../group__vidio.html#ga1861e510ea6fbc6192944cb4e80da6b8',1,'_NVVIOOUTPUTCONFIG_V1::outputRegion()'],['../group__vidio.html#ga31f7f4c6f041ab4b3431aa126fd8cece',1,'_NVVIOOUTPUTCONFIG_V2::outputRegion()'],['../group__vidio.html#ga397f011a277d7afbdf3c4c0d001ca1b9',1,'_NVVIOOUTPUTCONFIG_V3::outputRegion()']]],
  ['outputvideolocked',['outputVideoLocked',['../group__vidio.html#gae27ff8cef54cbd58d8fedd79ffbee474',1,'_NVVIOOUTPUTSTATUS']]],
  ['outstatus',['outStatus',['../group__vidio.html#gac1df634e615e476f4b717fc47cd4aca0',1,'_NVVIOSTATUS']]],
  ['ov',['ov',['../group__vidio.html#ga9afa0e75f07df06004b4c98fc2adc084',1,'_NV_GPU_PERF_PSTATES20_INFO_V2']]],
  ['overlapx',['overlapX',['../group__vidio.html#ga8b05f9df5dbf00ca0d520eb62a7d4545',1,'NV_MOSAIC_TOPO_DETAILS::overlapX()'],['../group__vidio.html#ga7bea581029a86ca348c0b99ae76cd1ee',1,'_NV_MOSAIC_GRID_TOPO_DISPLAY_V1::overlapX()'],['../group__vidio.html#gadd4c5e2369b8df91d3cf21e21e2a6558',1,'_NV_MOSAIC_GRID_TOPO_DISPLAY_V2::overlapX()'],['../group__vidio.html#gab6ada57fb4f13a495af964322a5bb5d7',1,'NV_MOSAIC_TOPOLOGY::overlapX()']]],
  ['overlapy',['overlapY',['../group__vidio.html#gaf3fa94f0cc3655609b77d8c34558d3d6',1,'NV_MOSAIC_TOPO_DETAILS::overlapY()'],['../group__vidio.html#ga3ccdaf5e5a8efadb0048d72eae648155',1,'_NV_MOSAIC_GRID_TOPO_DISPLAY_V1::overlapY()'],['../group__vidio.html#ga02c21cec8974e4df53f0cc3fb8407c50',1,'_NV_MOSAIC_GRID_TOPO_DISPLAY_V2::overlapY()'],['../group__vidio.html#ga1456a613299dffa12f8c57b0ecde618d',1,'NV_MOSAIC_TOPOLOGY::overlapY()']]],
  ['ownerid',['ownerId',['../group__vidio.html#ga3f596999cf163e5adc221cdd85919e3f',1,'_NVVIOCAPS']]],
  ['ownertype',['ownerType',['../group__vidio.html#ga14188e4b56518770e3a439adb3abc5fc',1,'_NVVIOCAPS']]]
];
