/*
 * Copyright 2018 Google LLC. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <ARKit/ARKit.h>

#import <Availability.h>

#import "GARSessionError.h"

@class GARAnchor;
@class GARFrame;
@class GARFramePair;
@protocol GARSessionDelegate;

NS_ASSUME_NONNULL_BEGIN

/**
 * ARCore Cloud Anchors session class. Adds **ARCore** features to an app using **ARKit**.
 * All `NSError`'s returned by methods in this class have domain GARSessionErrorDomain and code a
 * value of GARSessionErrorCode - see GARSessionError.h.
 * For Augmented Faces, see GARAugmentedFaceSession.
 */
API_AVAILABLE(ios(11.0))
@interface GARSession : NSObject

/**
 * The most recent frame pair, containing the most recent `ARFrame` passed into #update:error: and
 * the corresponding returned GARFrame.
 */
@property(atomic, readonly, nullable) GARFramePair *currentFramePair;

/**
 * The delegate for receiving callbacks about the GARSession.
 */
@property(atomic, weak, nullable) id<GARSessionDelegate> delegate;

/**
 * The dispatch queue on which the delegate receives calls.
 * If `nil`, callbacks happen on the main thread.
 */
@property(atomic, nullable) dispatch_queue_t delegateQueue;

/**
 * Creates a GARSession with an API key and bundle identifier.
 *
 * @param apiKey Your API key for **Google Cloud Services**.
 * @param bundleIdentifier The bundle identifier associated to your API key. If `nil`, defaults to
 *                         `[[NSBundle mainBundle] bundleIdentifier]`.
 * @param error Out parameter for an `NSError`. Possible errors:
 *              GARSessionErrorCodeDeviceNotCompatible - this device or OS version
 *                                                       is not currently supported.
 *              GARSessionErrorCodeInvalidArgument - API key is `nil` or empty.
 * @return The new GARSession, or `nil` if there is an error.
 */
+ (instancetype _Nullable)sessionWithAPIKey:(NSString *)apiKey
                           bundleIdentifier:(NSString *_Nullable)bundleIdentifier
                                      error:(NSError **)error;

/// @cond
/**
 * Use #sessionWithAPIKey:bundleIdentifier:error: to instantiate a GARSession.
 */
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
/// @endcond

/**
 * Updates the GARSession with an `ARFrame`.
 * Call this method with every `ARFrame` to keep the sessions synced. Can be called on any thread.
 * Normally, this should be called from your `ARSessionDelegate`'s
 * `session:didUpdateFrame:` method.
 *
 * @param frame The next `ARFrame` from **ARKit**.
 * @param error Out parameter for `NSError`. Possible errors:
 *              GARSessionErrorCodeInvalidArgument - invalid (`nil`) frame.
 *              GARSessionErrorCodeFrameOutOfOrder - frame has a smaller timestamp than previous.
 * @return The GARFrame corresponding to the `ARFrame` passed in, or `nil` if there is an error.
 */
- (GARFrame *_Nullable)update:(ARFrame *)frame error:(NSError **)error;

/**
 * Removes an anchor from the session.
 *
 * @param anchor The anchor to remove.
 */
- (void)removeAnchor:(GARAnchor *)anchor;

/**
 * Hosts a new Cloud Anchor based on an `ARAnchor`.
 *
 * The new anchor will have a cloud state of GARCloudAnchorStateTaskInProgress and its initial
 * transform will be set to that of the passed-in anchor. However, the two transforms may differ
 * over time.
 *
 * @param anchor The `ARAnchor` to host.
 * @param error Out parameter for an `NSError`. Possible errors:
 *              GARSessionErrorCodeInvalidArgument - invalid (`nil`) anchor.
 *              GARSessionErrorCodeNotTracking - bad current ARTrackingState.
 *              GARSessionErrorCodeResourceExhausted - tried to create too many Cloud Anchors.
 * @return The new GARAnchor, or `nil` if there is an error.
 */
- (GARAnchor *_Nullable)hostCloudAnchor:(ARAnchor *)anchor error:(NSError **)error;

/**
 * Resolves a Cloud Anchor with a given identifier.
 * The new anchor is immediately added to the session and returned, but without a valid transform.
 * You don’t need to wait for a call to resolve a Cloud Anchor to complete before
 * initiating another call. A session can be resolving up to 20 Cloud Anchors at a given time.
 * If resolving fails, the anchor will be automatically removed from the session.
 *
 * @param identifier The Cloud Anchor identifier for the anchor.
 * @param error Out parameter for an `NSError`. Possible errors:
 *              GARSessionErrorCodeInvalidArgument - invalid (`nil` or empty) identifier.
 *              GARSessionErrorCodeResourceExhausted - tried to create too many Cloud Anchors.
 * @return The new GARAnchor, or `nil` if there is an error.
 */
- (GARAnchor *_Nullable)resolveCloudAnchorWithIdentifier:(NSString *)identifier
                                                   error:(NSError **)error;

@end

NS_ASSUME_NONNULL_END
