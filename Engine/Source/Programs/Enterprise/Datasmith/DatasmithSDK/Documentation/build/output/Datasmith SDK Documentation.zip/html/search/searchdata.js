var indexSectionsWithContent =
{
  0: "abcdefgilmprstuw",
  1: "dfiu",
  2: "acegiprst",
  3: "bclmpr",
  4: "csw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

