/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Datasmith SDK", "index.html", [
    [ "Welcome to the Datasmith SDK", "index.html", null ],
    [ "Setting Up your Project", "projectsetup.html", null ],
    [ "Creating a Datasmith File", "exporting.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"class_f_datasmith_light_actor_element_impl.html#a0802ee881c0d1a343bc59795bb4e2bce",
"class_f_datasmith_meta_data_element_impl.html#a41f176033c00676db9f0c04f64d99c6a",
"class_f_datasmith_shader_element_impl.html#af9c156f9bfcc7dda197c100e482d0539",
"class_i_datasmith_custom_actor_element.html#a6603829c4f7744f976774b55558990f4",
"class_i_datasmith_progress_manager.html#ac1de6c831671b678b9967b5aa4a3e9a9",
"class_i_datasmith_u_e_pbr_material_element.html#a7aac2de63792140fbb9a165ac2cef944"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';