var class_i_datasmith_material_expression_flatten_normal =
[
    [ "GetFlatness", "class_i_datasmith_material_expression_flatten_normal.html#a04ea7799cfac797b5bfb4db2d6f764b0", null ],
    [ "GetFlatness", "class_i_datasmith_material_expression_flatten_normal.html#a97408924a389e2cddc3fd21707117ebd", null ],
    [ "GetNormal", "class_i_datasmith_material_expression_flatten_normal.html#a8954f038acaed2e4e747273b8c1142bb", null ],
    [ "GetNormal", "class_i_datasmith_material_expression_flatten_normal.html#ae4d8c9f13bd05cb12229472819a18a6b", null ]
];