var class_i_datasmith_material_expression_color =
[
    [ "GetColor", "class_i_datasmith_material_expression_color.html#a025adde136240df8beec4d74ef923d81", null ],
    [ "GetColor", "class_i_datasmith_material_expression_color.html#a774f3e1346ddc5f10cfce4406afdff10", null ]
];