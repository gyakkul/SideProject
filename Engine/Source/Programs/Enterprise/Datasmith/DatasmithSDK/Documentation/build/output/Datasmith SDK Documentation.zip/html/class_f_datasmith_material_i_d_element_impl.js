var class_f_datasmith_material_i_d_element_impl =
[
    [ "FDatasmithMaterialIDElementImpl", "class_f_datasmith_material_i_d_element_impl.html#a9ad43e52b6cac0389ef9d1bf79cbc37e", null ],
    [ "GetId", "class_f_datasmith_material_i_d_element_impl.html#a018bbb367891604e84376b3802b9236b", null ],
    [ "SetId", "class_f_datasmith_material_i_d_element_impl.html#a9e719f1426c124f09107dc9dafda619d", null ]
];