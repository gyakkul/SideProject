var class_i_datasmith_material_element =
[
    [ "~IDatasmithMaterialElement", "class_i_datasmith_material_element.html#a5b10d47129374bceac22c323ce498973", null ],
    [ "AddShader", "class_i_datasmith_material_element.html#a580bbaa1299917519e0a64f3b8af5058", null ],
    [ "GetShader", "class_i_datasmith_material_element.html#a8803ba144559b80af74b89139491ce3b", null ],
    [ "GetShader", "class_i_datasmith_material_element.html#a55e48531a749941e5d637ec1f6fa11e4", null ],
    [ "GetShadersCount", "class_i_datasmith_material_element.html#ab309d5a3e7cf7f2cdfa2538dd99f7ac1", null ],
    [ "IsClearCoatMaterial", "class_i_datasmith_material_element.html#a23f477f80d5ec39282cdcbc70ee8a250", null ],
    [ "IsSingleShaderMaterial", "class_i_datasmith_material_element.html#a4a859ba6978915f9690992deeed9aa55", null ]
];