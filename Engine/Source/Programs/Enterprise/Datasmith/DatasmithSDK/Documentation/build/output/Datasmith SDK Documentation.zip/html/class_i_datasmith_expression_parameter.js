var class_i_datasmith_expression_parameter =
[
    [ "~IDatasmithExpressionParameter", "class_i_datasmith_expression_parameter.html#a41eb08e0b7c2103b54e4acb38a478801", null ],
    [ "GetGroupName", "class_i_datasmith_expression_parameter.html#ac1e484c42221fc4c4775b35c6ece764b", null ],
    [ "SetGroupName", "class_i_datasmith_expression_parameter.html#a1a34284217d9e95cac63109b10cd2cd4", null ]
];