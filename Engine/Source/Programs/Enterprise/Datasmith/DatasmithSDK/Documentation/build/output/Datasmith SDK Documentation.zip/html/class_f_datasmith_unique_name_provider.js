var class_f_datasmith_unique_name_provider =
[
    [ "AddExistingName", "class_f_datasmith_unique_name_provider.html#acfe44f5c47371dc9e07ae4d5dca92ca5", null ],
    [ "Contains", "class_f_datasmith_unique_name_provider.html#aa7719394609896d0ba721e26c34f6fa3", null ],
    [ "RemoveExistingName", "class_f_datasmith_unique_name_provider.html#a1d268b7b015de33ac254403db0340c9c", null ],
    [ "Reserve", "class_f_datasmith_unique_name_provider.html#ad5e3970d8407618d62647add35393af7", null ]
];