var searchData=
[
  ['bdisablereflectionfresnel_1250',['bDisableReflectionFresnel',['../class_i_datasmith_shader_element.html#ae0b29980fa4abce07480b9e52368ccee',1,'IDatasmithShaderElement']]],
  ['buserealisticfresnel_1251',['bUseRealisticFresnel',['../class_i_datasmith_shader_element.html#a40f2046c7516d8e5686dccf76337eecd',1,'IDatasmithShaderElement']]]
];
