var class_i_datasmith_material_expression_function_call =
[
    [ "GetFunctionPathName", "class_i_datasmith_material_expression_function_call.html#ae1fee244c6c97818e40a82f0be63d0e9", null ],
    [ "SetFunctionPathName", "class_i_datasmith_material_expression_function_call.html#a647139b318ffa7b6cfa2720271491c32", null ]
];