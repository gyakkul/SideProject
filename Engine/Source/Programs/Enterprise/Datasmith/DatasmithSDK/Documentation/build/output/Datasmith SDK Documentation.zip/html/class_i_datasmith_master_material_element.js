var class_i_datasmith_master_material_element =
[
    [ "~IDatasmithMasterMaterialElement", "class_i_datasmith_master_material_element.html#a0aed9e7b08af838252f6239f669d7933", null ],
    [ "AddProperty", "class_i_datasmith_master_material_element.html#a14629945534b45381f5f32a33a31254e", null ],
    [ "GetCustomMaterialPathName", "class_i_datasmith_master_material_element.html#a66cf9bc453e0587673865e18184e6f3f", null ],
    [ "GetMaterialType", "class_i_datasmith_master_material_element.html#a23a34403f0ae277109ee77b21848330d", null ],
    [ "GetPropertiesCount", "class_i_datasmith_master_material_element.html#a161b626c3b28bc4aaac4d8145c65883f", null ],
    [ "GetProperty", "class_i_datasmith_master_material_element.html#a6cbd9562bccb1d01840753faab8537c8", null ],
    [ "GetProperty", "class_i_datasmith_master_material_element.html#ad711d985b0319a9f87fc84384782126f", null ],
    [ "GetPropertyByName", "class_i_datasmith_master_material_element.html#a3165972a7710d2c19a8578b950b82941", null ],
    [ "GetPropertyByName", "class_i_datasmith_master_material_element.html#a3392b6a6d6974f486dcc739d37c1b1ac", null ],
    [ "GetQuality", "class_i_datasmith_master_material_element.html#afc746223b2a089e3189c99b1a3a94745", null ],
    [ "SetCustomMaterialPathName", "class_i_datasmith_master_material_element.html#a388a74ff2ed18d6ddbc21ca759008a5b", null ],
    [ "SetMaterialType", "class_i_datasmith_master_material_element.html#aef8586f5825ba6e351c83ef9dc9c1af7", null ],
    [ "SetQuality", "class_i_datasmith_master_material_element.html#a67cb6e387fb4f052284fea42ea20846f", null ]
];