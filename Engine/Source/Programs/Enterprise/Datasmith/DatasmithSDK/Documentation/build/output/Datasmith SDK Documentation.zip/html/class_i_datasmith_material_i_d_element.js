var class_i_datasmith_material_i_d_element =
[
    [ "~IDatasmithMaterialIDElement", "class_i_datasmith_material_i_d_element.html#abb0ba9ac6136b96cfb8327f27d078e39", null ],
    [ "GetId", "class_i_datasmith_material_i_d_element.html#a8829480f7f1690e78ef78ccefea392c4", null ],
    [ "SetId", "class_i_datasmith_material_i_d_element.html#a5f1bcbbd6a107aaa2cf9a62f979e664a", null ]
];