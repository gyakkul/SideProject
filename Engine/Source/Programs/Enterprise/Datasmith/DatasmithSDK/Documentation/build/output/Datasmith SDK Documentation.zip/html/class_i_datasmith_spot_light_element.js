var class_i_datasmith_spot_light_element =
[
    [ "GetInnerConeAngle", "class_i_datasmith_spot_light_element.html#ae8783a35007f9e64eebb95e92b15c124", null ],
    [ "GetOuterConeAngle", "class_i_datasmith_spot_light_element.html#ab6b1672c33dc21a0f4fd5925316d6f74", null ],
    [ "SetInnerConeAngle", "class_i_datasmith_spot_light_element.html#a2239570fe19374b0f62aba92e4305d60", null ],
    [ "SetOuterConeAngle", "class_i_datasmith_spot_light_element.html#a201031c870616c637ca365d5c64527f9", null ]
];