var searchData=
[
  ['creating_20a_20datasmith_20file_1257',['Creating a Datasmith File',['../exporting.html',1,'']]]
];
