// Fill out your copyright notice in the Description page of Project Settings.


#include "ArraySnippet.h"

ArraySnippet::ArraySnippet()
{
}

ArraySnippet::~ArraySnippet()
{
}

///CODE_SNIPPET_START: TArray::Add
void ArraySnippet::PushBack()
{

	// Push new elements to the back of the array.
	StringArray.Add(TEXT("Hello"));
	StringArray.Add(TEXT("Unreal"));
	StringArray.Add(TEXT("Engine"));
	//StringArray == ["Hello","Unreal","Engine"]
}
///CODE_SNIPPET_END

void ArraySnippet::PrintContents()
{
	//Print the array's contents.
	for (int i = 0; i < StringArray.Num(); ++i)
		UE_LOG(LogTemp, Warning, TEXT("%s"), *StringArray[i]);
}
