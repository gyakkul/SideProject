// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "SnippetSamples/ArraySnippet.h"
#include "ExampleSnippetPrjGameMode.generated.h"

UCLASS(minimalapi)
class AExampleSnippetPrjGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AExampleSnippetPrjGameMode();
	
	void StartPlay();
};



