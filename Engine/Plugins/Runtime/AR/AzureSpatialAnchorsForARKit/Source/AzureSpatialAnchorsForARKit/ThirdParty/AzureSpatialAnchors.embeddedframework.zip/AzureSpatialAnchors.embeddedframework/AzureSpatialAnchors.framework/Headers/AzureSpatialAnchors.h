//
//  AzureSpatialAnchors.h
//  AzureSpatialAnchors
//
//  Copyright © Microsoft Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AzureSpatialAnchors/AzureSpatialAnchorsLibrary.h>

//! Project version number for AzureSpatialAnchors.
FOUNDATION_EXPORT double AzureSpatialAnchorsVersionNumber;

//! Project version string for AzureSpatialAnchors.
FOUNDATION_EXPORT const unsigned char AzureSpatialAnchorsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AzureSpatialAnchors/PublicHeader.h>

